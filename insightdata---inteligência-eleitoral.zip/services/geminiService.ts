import { GoogleGenAI } from "@google/genai";
import { SurveyResponse, Survey } from "../types";

// Note: In a real app, strict error handling for missing API keys is needed.
const getClient = () => {
  const apiKey = process.env.API_KEY || '';
  if (!apiKey) {
    console.warn("API Key is missing. AI features will not work.");
  }
  return new GoogleGenAI({ apiKey });
};

export const generatePoliticalAnalysis = async (
  survey: Survey,
  responses: SurveyResponse[]
): Promise<string> => {
  const ai = getClient();
  
  // Aggregate data for the prompt to save tokens and provide clarity
  const total = responses.length;
  const voteCounts: Record<string, number> = {};
  const neighborhoodIssues: Record<string, Record<string, number>> = {};
  const ageDistribution: Record<string, number> = {};

  responses.forEach(r => {
    // Vote Intent (q1)
    const vote = r.answers['q1'] as string;
    voteCounts[vote] = (voteCounts[vote] || 0) + 1;

    // Age
    ageDistribution[r.respondentProfile.ageGroup] = (ageDistribution[r.respondentProfile.ageGroup] || 0) + 1;

    // Issues by neighborhood (q3)
    const hood = r.respondentProfile.neighborhood;
    const issue = r.answers['q3'] as string;
    if (!neighborhoodIssues[hood]) neighborhoodIssues[hood] = {};
    neighborhoodIssues[hood][issue] = (neighborhoodIssues[hood][issue] || 0) + 1;
  });

  const promptData = JSON.stringify({
    surveyTitle: survey.title,
    totalSamples: total,
    voteIntent: voteCounts,
    topProblemsByRegion: neighborhoodIssues,
    demographics: ageDistribution
  }, null, 2);

  const systemInstruction = `
    Você é um Cientista Político Sênior e Estrategista Eleitoral especialista em dados.
    
    Sua tarefa é analisar os dados brutos JSON de uma pesquisa eleitoral e gerar um relatório estratégico profissional em formato Markdown.
    
    O relatório DEVE conter as seguintes seções:
    1. **Diagnóstico Geral**: Resumo executivo da situação.
    2. **Forças e Fraquezas por Região**: Onde o candidato (Situação/Oposição) está forte ou fraco.
    3. **Análise de Rejeição e Insatisfação**: Baseado nos principais problemas relatados por bairro.
    4. **Recomendações Estratégicas**:
       - Qual tom de discurso adotar?
       - Quais temas priorizar em cada região?
       - Sugestões de ações de "Ground Game" (campanha de rua).
    
    Use linguagem formal, objetiva e persuasiva.
    Seja específico. Se a Zona Sul reclama de segurança, sugira ações sobre isso.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Analise estes dados de pesquisa: ${promptData}`,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7, // Creative but analytical
      }
    });

    return response.text || "Não foi possível gerar a análise.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Erro ao conectar com a IA. Verifique a chave de API.";
  }
};