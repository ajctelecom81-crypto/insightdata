import { Survey, SurveyResponse, User, UserRole, QuestionType } from '../types';

// Mock Data Initialization
const MOCK_USERS: User[] = [
  { id: '1', name: 'Administrador Geral', role: UserRole.ADMIN, email: 'admin@insightdata.com' },
  { id: '2', name: 'João Campo', role: UserRole.RESEARCHER, email: 'joao@insightdata.com', token: 'RES-001' },
  { id: '3', name: 'Maria Rua', role: UserRole.RESEARCHER, email: 'maria@insightdata.com', token: 'RES-002' },
];

const MOCK_SURVEY: Survey = {
  id: 's1',
  title: 'Eleições Municipais 2025 - 1º Turno',
  description: 'Pesquisa de intenção de voto para prefeito.',
  active: true,
  region: 'São Paulo - Capital',
  // Configuração de Geofence (Ex: Centro de SP)
  targetLocation: {
    lat: -23.550520, 
    lng: -46.633308
  },
  allowedRadius: 5000, // 5km de raio permitido
  questions: [
    {
      id: 'q1',
      text: 'Se a eleição fosse hoje, em quem você votaria?',
      type: QuestionType.SINGLE_CHOICE,
      options: ['Candidato A (Situação)', 'Candidato B (Oposição)', 'Candidato C (Terceira Via)', 'Branco/Nulo', 'Indeciso']
    },
    {
      id: 'q2',
      text: 'Como você avalia a atual gestão da prefeitura?',
      type: QuestionType.SCALE, // 1 (Péssimo) - 5 (Ótimo)
    },
    {
      id: 'q3',
      text: 'Qual o principal problema do seu bairro?',
      type: QuestionType.SINGLE_CHOICE,
      options: ['Saúde', 'Segurança', 'Educação', 'Transporte', 'Zeladoria']
    },
    {
      id: 'q4',
      text: 'Você conhece o Candidato B?',
      type: QuestionType.BOOLEAN
    },
    {
      id: 'q5',
      text: 'Qual sua posição sobre o Projeto de Lei de Revitalização do Centro?',
      type: QuestionType.SINGLE_CHOICE,
      options: ['Aprova', 'Não Aprova', 'Não Sabe']
    }
  ]
};

// Generate some mock responses for charts
const generateMockResponses = (): SurveyResponse[] => {
  const responses: SurveyResponse[] = [];
  const neighborhoods = ['Centro', 'Zona Sul', 'Zona Norte', 'Zona Leste', 'Zona Oeste'];
  const candidates = ['Candidato A (Situação)', 'Candidato B (Oposição)', 'Candidato C (Terceira Via)', 'Branco/Nulo', 'Indeciso'];
  const plOpinions = ['Aprova', 'Não Aprova', 'Não Sabe'];

  for (let i = 0; i < 50; i++) {
    const neighborhood = neighborhoods[Math.floor(Math.random() * neighborhoods.length)];
    // Bias: South prefers A, North prefers B
    let vote = candidates[Math.floor(Math.random() * candidates.length)];
    if (neighborhood === 'Zona Sul' && Math.random() > 0.4) vote = candidates[0];
    if (neighborhood === 'Zona Norte' && Math.random() > 0.4) vote = candidates[1];

    responses.push({
      id: `r${i}`,
      surveyId: 's1',
      researcherId: i % 2 === 0 ? '2' : '3',
      researcherName: i % 2 === 0 ? 'João Campo' : 'Maria Rua',
      location: {
        lat: -23.5505 + (Math.random() - 0.5) * 0.1,
        lng: -46.6333 + (Math.random() - 0.5) * 0.1,
        accuracy: 10,
        timestamp: Date.now()
      },
      submittedAt: new Date().toISOString(),
      respondentProfile: {
        ageGroup: Math.random() > 0.5 ? '25-34' : '45-59',
        gender: Math.random() > 0.5 ? 'M' : 'F',
        neighborhood: neighborhood
      },
      answers: {
        'q1': vote,
        'q2': Math.floor(Math.random() * 5) + 1,
        'q3': ['Saúde', 'Segurança', 'Transporte'][Math.floor(Math.random() * 3)],
        'q4': Math.random() > 0.3,
        'q5': plOpinions[Math.floor(Math.random() * plOpinions.length)]
      }
    });
  }
  return responses;
};

// Local Storage Keys
const KEYS = {
  RESPONSES: 'id_responses',
  SURVEYS: 'id_surveys',
  USERS: 'id_users'
};

export const getSurveys = (): Survey[] => {
  const stored = localStorage.getItem(KEYS.SURVEYS);
  if (!stored) {
    localStorage.setItem(KEYS.SURVEYS, JSON.stringify([MOCK_SURVEY]));
    return [MOCK_SURVEY];
  }
  return JSON.parse(stored);
};

export const saveSurvey = (newSurvey: Survey) => {
  const surveys = getSurveys();
  surveys.unshift(newSurvey); // Add to the beginning
  localStorage.setItem(KEYS.SURVEYS, JSON.stringify(surveys));
};

export const getResponses = (): SurveyResponse[] => {
  const stored = localStorage.getItem(KEYS.RESPONSES);
  if (!stored) {
    const mocks = generateMockResponses();
    localStorage.setItem(KEYS.RESPONSES, JSON.stringify(mocks));
    return mocks;
  }
  return JSON.parse(stored);
};

export const saveResponse = (response: SurveyResponse) => {
  const responses = getResponses();
  responses.push(response);
  localStorage.setItem(KEYS.RESPONSES, JSON.stringify(responses));
};

// User Management Logic

export const getUsers = (): User[] => {
  const stored = localStorage.getItem(KEYS.USERS);
  if (!stored) {
    // If no users in storage, init with mocks
    localStorage.setItem(KEYS.USERS, JSON.stringify(MOCK_USERS));
    return MOCK_USERS;
  }
  return JSON.parse(stored);
};

export const registerResearcher = (name: string, email?: string): User => {
  const users = getUsers();
  
  // Generate a simple token (e.g., RES-XYZ123)
  const token = `RES-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
  
  // Create a placeholder email if not provided to satisfy the Type contract
  const finalEmail = email || `${name.toLowerCase().replace(/[^a-z0-9]/g, '')}.${token.toLowerCase()}@insightdata.local`;
  
  const newUser: User = {
    id: Date.now().toString(),
    name,
    email: finalEmail,
    role: UserRole.RESEARCHER,
    token
  };

  users.push(newUser);
  localStorage.setItem(KEYS.USERS, JSON.stringify(users));
  return newUser;
};

export const deleteUser = (id: string) => {
  const users = getUsers().filter(u => u.id !== id);
  localStorage.setItem(KEYS.USERS, JSON.stringify(users));
}

export const authenticate = (emailOrToken: string): User | undefined => {
  const users = getUsers();
  return users.find(u => u.email === emailOrToken || u.token === emailOrToken);
};