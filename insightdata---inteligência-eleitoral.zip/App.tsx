import React, { useState, useEffect } from 'react';
import { User, UserRole, SurveyResponse, Survey } from './types';
import { getSurveys, getResponses, authenticate, getUsers } from './services/storageService';
import { Icons } from './components/Icons';
import { AdminDashboard } from './components/AdminDashboard';
import { DataCollection } from './components/DataCollection';
import { SurveyCreator } from './components/SurveyCreator';
import { ResearcherManager } from './components/ResearcherManager';

// Simple Router States
type ViewState = 'LOGIN' | 'DASHBOARD' | 'COLLECTION' | 'USERS' | 'CREATE_SURVEY';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [view, setView] = useState<ViewState>('LOGIN');
  const [surveys, setSurveys] = useState<Survey[]>([]);
  const [responses, setResponses] = useState<SurveyResponse[]>([]);
  const [loginInput, setLoginInput] = useState('');

  // Initial Load
  useEffect(() => {
    setSurveys(getSurveys());
    setResponses(getResponses());
  }, []);

  const handleLogin = (identifier: string) => {
    const foundUser = authenticate(identifier);
    if (foundUser) {
      setUser(foundUser);
      if (foundUser.role === UserRole.ADMIN) {
        setView('DASHBOARD');
      } else {
        setView('COLLECTION');
      }
    } else {
      alert("Credenciais inválidas. Tente: admin@insightdata.com ou um Token válido.");
    }
  };

  const handleLogout = () => {
    setUser(null);
    setView('LOGIN');
    setLoginInput('');
  };

  const refreshData = () => {
    setResponses(getResponses());
    setSurveys(getSurveys());
  };

  const handleCreateSurveySuccess = () => {
    refreshData();
    setView('DASHBOARD');
    alert("Pesquisa criada com sucesso!");
  };

  // Login Screen
  if (view === 'LOGIN' || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-900 p-4">
        <div className="bg-white p-8 rounded-xl shadow-2xl w-full max-w-md">
          <div className="flex justify-center mb-6">
            <div className="bg-blue-600 p-3 rounded-full">
              <Icons.Check className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-center text-slate-800 mb-2">InsightData</h1>
          <p className="text-center text-slate-500 mb-8">Inteligência Eleitoral & Coleta de Dados</p>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Acesso ao Sistema</label>
              <input 
                value={loginInput}
                onChange={(e) => setLoginInput(e.target.value)}
                placeholder="E-mail ou Token de Acesso"
                className="w-full p-3 border border-slate-300 rounded-lg mb-4 outline-none focus:ring-2 focus:ring-blue-600"
              />
              <button 
                onClick={() => handleLogin(loginInput)}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg transition"
              >
                Entrar
              </button>
            </div>

            <div className="relative flex py-2 items-center">
                <div className="flex-grow border-t border-slate-200"></div>
                <span className="flex-shrink-0 mx-4 text-slate-400 text-xs">Acesso Rápido (Demo)</span>
                <div className="flex-grow border-t border-slate-200"></div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button 
                onClick={() => handleLogin('admin@insightdata.com')}
                className="flex flex-col items-center justify-center p-3 border border-slate-200 rounded-lg hover:bg-slate-50 transition text-xs text-slate-600"
              >
                <Icons.Dashboard className="w-5 h-5 mb-1 text-blue-600" />
                Admin
              </button>
              <button 
                onClick={() => handleLogin('RES-001')}
                className="flex flex-col items-center justify-center p-3 border border-slate-200 rounded-lg hover:bg-slate-50 transition text-xs text-slate-600"
              >
                <Icons.Map className="w-5 h-5 mb-1 text-green-600" />
                Pesquisador
              </button>
            </div>
          </div>
          <p className="mt-8 text-xs text-center text-slate-400">
            Ambiente seguro. Protegido por criptografia ponta-a-ponta.
          </p>
        </div>
      </div>
    );
  }

  // Researcher View
  if (user.role === UserRole.RESEARCHER) {
    return (
      <div className="min-h-screen bg-slate-100">
        <header className="bg-white shadow px-4 py-4 flex justify-between items-center sticky top-0 z-50">
          <div className="flex items-center">
             <div className="bg-green-600 p-1.5 rounded-lg mr-2">
                <Icons.Map className="w-5 h-5 text-white" />
             </div>
             <div>
               <h1 className="font-bold text-slate-800 leading-tight">Painel de Coleta</h1>
               <p className="text-xs text-slate-500">Olá, {user.name}</p>
             </div>
          </div>
          <button onClick={handleLogout} className="text-slate-400 hover:text-red-500">
            <Icons.Logout className="w-6 h-6" />
          </button>
        </header>
        <main className="p-4">
           {surveys.length > 0 ? (
             <DataCollection 
                user={user} 
                survey={surveys[0]} 
                onSubmitSuccess={refreshData} 
             />
           ) : (
             <p className="text-center text-slate-500 mt-10">Nenhuma pesquisa ativa no momento.</p>
           )}
        </main>
      </div>
    );
  }

  // Admin View
  return (
    <div className="min-h-screen bg-slate-100 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white hidden md:flex flex-col">
        <div className="p-6 border-b border-slate-800">
          <div className="flex items-center gap-3">
             <div className="bg-blue-600 p-2 rounded-lg">
                <Icons.Check className="w-6 h-6" />
             </div>
             <span className="font-bold text-lg">InsightData</span>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-2">
          <button 
            onClick={() => setView('DASHBOARD')}
            className={`flex items-center w-full p-3 rounded-lg transition ${view === 'DASHBOARD' || view === 'CREATE_SURVEY' ? 'bg-blue-600' : 'hover:bg-slate-800'}`}
          >
            <Icons.Dashboard className="w-5 h-5 mr-3" />
            Dashboard
          </button>
          
          <button 
             onClick={() => setView('USERS')}
            className={`flex items-center w-full p-3 rounded-lg transition ${view === 'USERS' ? 'bg-blue-600' : 'hover:bg-slate-800'}`}
          >
            <Icons.Users className="w-5 h-5 mr-3" />
            Equipe de Campo
          </button>
        </nav>

        <div className="p-4 border-t border-slate-800">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center">
              {user.name.charAt(0)}
            </div>
            <div className="overflow-hidden">
              <p className="text-sm font-medium truncate">{user.name}</p>
              <p className="text-xs text-slate-400 truncate">Administrador</p>
            </div>
          </div>
          <button 
            onClick={handleLogout}
            className="flex items-center text-sm text-slate-400 hover:text-white transition"
          >
            <Icons.Logout className="w-4 h-4 mr-2" /> Sair
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden bg-white shadow p-4 flex justify-between items-center z-20">
           <span className="font-bold">InsightData ADM</span>
           <button onClick={handleLogout}><Icons.Logout className="w-6 h-6" /></button>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-8">
          {view === 'DASHBOARD' && (
            <AdminDashboard 
              surveys={surveys} 
              responses={responses} 
              onCreateSurvey={() => setView('CREATE_SURVEY')}
            />
          )}
          {view === 'CREATE_SURVEY' && (
            <SurveyCreator 
              onCancel={() => setView('DASHBOARD')}
              onSave={handleCreateSurveySuccess}
            />
          )}
          {view === 'USERS' && (
            <ResearcherManager />
          )}
        </main>
      </div>
    </div>
  );
};

export default App;