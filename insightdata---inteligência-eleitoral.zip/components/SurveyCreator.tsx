import React, { useState } from 'react';
import { Survey, Question, QuestionType } from '../types';
import { Icons } from './Icons';
import { saveSurvey } from '../services/storageService';

interface Props {
  onCancel: () => void;
  onSave: () => void;
}

export const SurveyCreator: React.FC<Props> = ({ onCancel, onSave }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [region, setRegion] = useState('');
  const [questions, setQuestions] = useState<Question[]>([]);

  const addQuestion = () => {
    const newQ: Question = {
      id: `q${Date.now()}`,
      text: '',
      type: QuestionType.SINGLE_CHOICE,
      options: ['Opção 1', 'Opção 2']
    };
    setQuestions([...questions, newQ]);
  };

  const updateQuestion = (id: string, field: keyof Question, value: any) => {
    setQuestions(questions.map(q => q.id === id ? { ...q, [field]: value } : q));
  };

  const updateOption = (qId: string, optIndex: number, val: string) => {
    setQuestions(questions.map(q => {
      if (q.id === qId && q.options) {
        const newOpts = [...q.options];
        newOpts[optIndex] = val;
        return { ...q, options: newOpts };
      }
      return q;
    }));
  };

  const addOption = (qId: string) => {
    setQuestions(questions.map(q => {
      if (q.id === qId && q.options) {
        return { ...q, options: [...q.options, `Nova Opção`] };
      }
      return q;
    }));
  };

  const removeOption = (qId: string, optIndex: number) => {
    setQuestions(questions.map(q => {
      if (q.id === qId && q.options) {
        return { ...q, options: q.options.filter((_, i) => i !== optIndex) };
      }
      return q;
    }));
  };

  const removeQuestion = (id: string) => {
    setQuestions(questions.filter(q => q.id !== id));
  };

  const handleSave = () => {
    if (!title || !description || questions.length === 0) {
      alert("Por favor, preencha o título, descrição e adicione ao menos uma pergunta.");
      return;
    }

    const newSurvey: Survey = {
      id: `s${Date.now()}`,
      title,
      description,
      region: region || 'Geral',
      active: true,
      questions
    };

    saveSurvey(newSurvey);
    onSave();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      <div className="flex items-center justify-between mb-6">
        <div>
           <h2 className="text-3xl font-bold text-slate-800">Nova Pesquisa</h2>
           <p className="text-slate-500">Configure os detalhes e as perguntas do formulário.</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 space-y-4">
        <h3 className="font-bold text-lg text-slate-700 flex items-center">
            <Icons.Report className="w-5 h-5 mr-2" /> Informações Básicas
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="block text-sm font-medium text-slate-700 mb-1">Título da Pesquisa</label>
            <input 
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full p-3 border rounded-lg bg-slate-50 focus:ring-2 focus:ring-blue-500 outline-none" 
              placeholder="Ex: Eleições 2026 - Intenção de Voto" 
            />
          </div>
          <div className="col-span-2">
             <label className="block text-sm font-medium text-slate-700 mb-1">Descrição / Instruções</label>
             <textarea 
               value={description}
               onChange={e => setDescription(e.target.value)}
               className="w-full p-3 border rounded-lg bg-slate-50 focus:ring-2 focus:ring-blue-500 outline-none" 
               placeholder="Ex: Pesquisa focada nos bairros da zona norte..." 
             />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Região de Aplicação</label>
            <input 
              value={region}
              onChange={e => setRegion(e.target.value)}
              className="w-full p-3 border rounded-lg bg-slate-50 focus:ring-2 focus:ring-blue-500 outline-none" 
              placeholder="Ex: São Paulo - Capital" 
            />
          </div>
        </div>
      </div>

      <div className="space-y-4">
         <div className="flex justify-between items-center">
            <h3 className="font-bold text-lg text-slate-700">Perguntas do Questionário</h3>
            <button onClick={addQuestion} className="flex items-center text-sm font-bold text-blue-600 hover:text-blue-700 bg-blue-50 px-3 py-2 rounded-lg">
                <Icons.Plus className="w-4 h-4 mr-1" /> Adicionar Pergunta
            </button>
         </div>

         {questions.map((q, idx) => (
           <div key={q.id} className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 relative group">
              <button 
                onClick={() => removeQuestion(q.id)}
                className="absolute top-4 right-4 text-slate-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition"
              >
                  <Icons.Logout className="w-5 h-5" /> {/* Using logout icon as placeholder for Trash/X if needed, or stick to simple */}
                  <span className="text-xs ml-1">Remover</span>
              </button>
              
              <div className="flex gap-4 items-start mb-4">
                 <span className="bg-slate-100 text-slate-500 font-bold px-3 py-1 rounded text-sm">#{idx + 1}</span>
                 <div className="flex-1 space-y-3">
                    <input 
                      value={q.text}
                      onChange={e => updateQuestion(q.id, 'text', e.target.value)}
                      className="w-full p-2 border-b-2 border-slate-200 focus:border-blue-600 outline-none bg-transparent font-medium text-lg placeholder-slate-300" 
                      placeholder="Digite a pergunta aqui..."
                    />
                    <div className="flex items-center gap-2">
                        <label className="text-sm text-slate-500">Tipo de Resposta:</label>
                        <select 
                           value={q.type}
                           onChange={e => updateQuestion(q.id, 'type', e.target.value)}
                           className="p-2 border rounded bg-slate-50 text-sm"
                        >
                           <option value={QuestionType.SINGLE_CHOICE}>Múltipla Escolha (Única)</option>
                           <option value={QuestionType.SCALE}>Escala de Avaliação (1 a 5)</option>
                           <option value={QuestionType.BOOLEAN}>Sim / Não</option>
                           <option value={QuestionType.TEXT}>Texto Livre</option>
                        </select>
                    </div>
                 </div>
              </div>

              {q.type === QuestionType.SINGLE_CHOICE && (
                  <div className="pl-12 space-y-2">
                      {q.options?.map((opt, optIdx) => (
                          <div key={optIdx} className="flex items-center gap-2">
                              <div className="w-4 h-4 rounded-full border border-slate-300"></div>
                              <input 
                                value={opt}
                                onChange={e => updateOption(q.id, optIdx, e.target.value)}
                                className="flex-1 p-2 border rounded bg-slate-50 text-sm"
                                placeholder={`Opção ${optIdx + 1}`}
                              />
                              <button onClick={() => removeOption(q.id, optIdx)} className="text-slate-400 hover:text-red-500 px-2">x</button>
                          </div>
                      ))}
                      <button onClick={() => addOption(q.id)} className="text-sm text-blue-600 hover:underline pl-6">+ Adicionar Opção</button>
                  </div>
              )}
           </div>
         ))}
      </div>

      <div className="fixed bottom-0 left-0 md:left-64 right-0 bg-white p-4 border-t border-slate-200 flex justify-end gap-3 z-10">
          <button 
             onClick={onCancel}
             className="px-6 py-2 border border-slate-300 rounded-lg text-slate-700 font-medium hover:bg-slate-50"
          >
              Cancelar
          </button>
          <button 
             onClick={handleSave}
             className="px-6 py-2 bg-green-600 text-white rounded-lg font-bold hover:bg-green-700 shadow-lg shadow-green-600/20 flex items-center"
          >
              <Icons.Check className="w-5 h-5 mr-2" /> Salvar e Publicar
          </button>
      </div>
    </div>
  );
};