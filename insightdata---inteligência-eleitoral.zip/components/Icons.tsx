import React from 'react';
import { 
  LayoutDashboard, 
  MapPin, 
  FileText, 
  Users, 
  LogOut, 
  BrainCircuit, 
  CheckCircle,
  PlusCircle,
  BarChart3,
  Send,
  Loader2,
  Key,
  Copy,
  Trash2,
  Download,
  Calendar
} from 'lucide-react';

export const Icons = {
  Dashboard: LayoutDashboard,
  Map: MapPin,
  Report: FileText,
  Users: Users,
  Logout: LogOut,
  AI: BrainCircuit,
  Check: CheckCircle,
  Plus: PlusCircle,
  Chart: BarChart3,
  Send: Send,
  Spinner: Loader2,
  Key: Key,
  Copy: Copy,
  Trash: Trash2,
  Download: Download,
  Calendar: Calendar
};