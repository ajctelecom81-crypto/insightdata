import React, { useState, useMemo } from 'react';
import { Survey, SurveyResponse } from '../types';
import { Icons } from './Icons';
import { generatePoliticalAnalysis } from '../services/geminiService';
import ReactMarkdown from 'react-markdown';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, ScatterChart, Scatter, ZAxis
} from 'recharts';

interface Props {
  surveys: Survey[];
  responses: SurveyResponse[];
  onCreateSurvey: () => void;
}

const COLORS = ['#2563eb', '#dc2626', '#16a34a', '#d97706', '#9333ea', '#64748b'];

export const AdminDashboard: React.FC<Props> = ({ surveys, responses, onCreateSurvey }) => {
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [filterPeriod, setFilterPeriod] = useState('all'); // all, today, week, month, year
  const [filterNeighborhood, setFilterNeighborhood] = useState('all');

  const activeSurvey = surveys[0]; // Assuming single active survey for demo

  // Extract unique neighborhoods from responses to populate filter
  const availableNeighborhoods = useMemo(() => {
    const hoods = new Set(responses.map(r => r.respondentProfile.neighborhood));
    return Array.from(hoods).filter(Boolean).sort();
  }, [responses]);

  // Filter Logic (Combines Date + Neighborhood)
  const filteredResponses = useMemo(() => {
    const now = new Date();
    return responses.filter(r => {
      // 1. Date Filter
      let dateMatch = true;
      if (filterPeriod !== 'all') {
        const responseDate = new Date(r.submittedAt);
        if (filterPeriod === 'today') {
          dateMatch = responseDate.toDateString() === now.toDateString();
        } else {
          const diffTime = Math.abs(now.getTime() - responseDate.getTime());
          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
          if (filterPeriod === 'week') dateMatch = diffDays <= 7;
          else if (filterPeriod === 'month') dateMatch = diffDays <= 30;
          else if (filterPeriod === 'year') dateMatch = diffDays <= 365;
        }
      }

      // 2. Neighborhood Filter
      let hoodMatch = true;
      if (filterNeighborhood !== 'all') {
        hoodMatch = r.respondentProfile.neighborhood === filterNeighborhood;
      }
      
      return dateMatch && hoodMatch;
    });
  }, [responses, filterPeriod, filterNeighborhood]);

  // Data Processing for Charts (Using Filtered Data)
  const voteData = useMemo(() => {
    const counts: Record<string, number> = {};
    filteredResponses.forEach(r => {
      const vote = r.answers['q1'] as string;
      counts[vote] = (counts[vote] || 0) + 1;
    });
    return Object.keys(counts).map(key => ({ name: key, votos: counts[key] }));
  }, [filteredResponses]);

  const rejectionData = useMemo(() => {
      // Mock rejection logic based on filtered responses
      if (filteredResponses.length === 0) return [];
      
      // In a real app, this would calculate actual rejection from a specific question
      // Here we simulate scaling based on sample size
      return [
          { name: 'Candidato A', value: Math.max(0, Math.floor(filteredResponses.length * 0.3)) },
          { name: 'Candidato B', value: Math.max(0, Math.floor(filteredResponses.length * 0.45)) },
          { name: 'Candidato C', value: Math.max(0, Math.floor(filteredResponses.length * 0.15)) },
          { name: 'Outros', value: Math.max(0, Math.floor(filteredResponses.length * 0.1)) },
      ].filter(item => item.value > 0);
  }, [filteredResponses]);

  const mapPoints = useMemo(() => {
    return filteredResponses.map(r => ({
      x: r.location.lng,
      y: r.location.lat,
      z: 1,
      neighborhood: r.respondentProfile.neighborhood
    }));
  }, [filteredResponses]);

  const handleGenerateReport = async () => {
    if (!process.env.API_KEY) {
        alert("API Key não encontrada no ambiente. A análise de IA não funcionará.");
        return;
    }
    if (filteredResponses.length === 0) {
      alert("Não há dados no período/bairro selecionado para gerar análise.");
      return;
    }
    setAnalyzing(true);
    // Pass filtered responses to AI
    const report = await generatePoliticalAnalysis(activeSurvey, filteredResponses);
    setAnalysis(report);
    setAnalyzing(false);
  };

  const handleExportPDF = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header específico para impressão (invisível na tela) */}
      <div className="print-header">
        <h1 className="text-2xl font-bold text-slate-900">Relatório Estratégico de Campanha</h1>
        <p className="text-slate-500">Gerado pelo sistema InsightData em {new Date().toLocaleDateString()}</p>
        <div className="text-sm text-slate-400 mt-2 flex gap-4 border-t pt-2 mt-2">
           <span>
             <strong>Período:</strong> {filterPeriod === 'all' ? 'Todo o Período' : 
               filterPeriod === 'today' ? 'Apenas Hoje' :
               filterPeriod === 'week' ? 'Últimos 7 dias' :
               filterPeriod === 'month' ? 'Últimos 30 dias' : 'Último Ano'}
           </span>
           <span>
             <strong>Bairro:</strong> {filterNeighborhood === 'all' ? 'Todos os Bairros' : filterNeighborhood}
           </span>
           <span>
             <strong>Amostra:</strong> {filteredResponses.length} entrevistas
           </span>
        </div>
      </div>

      <div className="flex flex-col xl:flex-row justify-between items-end xl:items-center gap-4">
        <div>
           <h2 className="text-3xl font-bold text-slate-800">Dashboard Estratégico</h2>
           <p className="text-slate-500">Monitoramento em tempo real da campanha.</p>
        </div>
        
        <div className="flex flex-wrap gap-2 no-print items-center justify-end">
            {/* Neighborhood Filter */}
            <div className="relative min-w-[180px]">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-500">
                <Icons.Map className="w-4 h-4" />
              </div>
              <select
                value={filterNeighborhood}
                onChange={(e) => setFilterNeighborhood(e.target.value)}
                className="bg-white border border-slate-300 text-slate-700 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5 shadow-sm appearance-none cursor-pointer hover:bg-slate-50 transition"
              >
                <option value="all">Todos os Bairros</option>
                {availableNeighborhoods.map(hood => (
                  <option key={hood} value={hood}>{hood}</option>
                ))}
              </select>
            </div>

            {/* Date Filter */}
            <div className="relative min-w-[160px]">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-500">
                <Icons.Calendar className="w-4 h-4" />
              </div>
              <select
                value={filterPeriod}
                onChange={(e) => setFilterPeriod(e.target.value)}
                className="bg-white border border-slate-300 text-slate-700 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 p-2.5 shadow-sm appearance-none cursor-pointer hover:bg-slate-50 transition"
              >
                <option value="all">Todo o Período</option>
                <option value="today">Hoje</option>
                <option value="week">Últimos 7 dias</option>
                <option value="month">Últimos 30 dias</option>
                <option value="year">Último Ano</option>
              </select>
            </div>

            <div className="h-8 w-px bg-slate-300 mx-1 hidden md:block"></div>

            <button 
                onClick={handleExportPDF}
                className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-medium py-2 px-4 rounded-lg flex items-center shadow-sm transition"
            >
                <Icons.Download className="w-5 h-5 md:mr-2" />
                <span className="hidden md:inline">PDF</span>
            </button>
            <button 
                onClick={onCreateSurvey}
                className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg flex items-center shadow transition"
            >
                <Icons.Plus className="w-5 h-5 md:mr-2" />
                <span className="hidden md:inline">Pesquisa</span>
            </button>
            
            <div className="bg-white px-4 py-2 rounded-lg shadow-sm border border-slate-200 text-sm hidden xl:block">
                <span className="text-slate-400 block text-xs uppercase font-bold">Total Amostra</span>
                <span className="text-2xl font-bold text-slate-800">{filteredResponses.length}</span>
            </div>
        </div>
      </div>

      {filteredResponses.length === 0 ? (
        <div className="bg-white p-12 rounded-xl shadow-sm border border-slate-200 text-center">
          <div className="inline-flex bg-slate-100 p-4 rounded-full mb-4">
            <Icons.Chart className="w-8 h-8 text-slate-400" />
          </div>
          <h3 className="text-lg font-bold text-slate-700">Nenhum dado encontrado</h3>
          <p className="text-slate-500">Não há coletas correspondentes aos filtros selecionados (Data/Bairro).</p>
        </div>
      ) : (
        /* Main Stats Grid */
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Vote Intent Chart */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 break-inside-avoid">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-slate-700 flex items-center">
                <Icons.Chart className="w-5 h-5 mr-2 text-blue-600" />
                Intenção de Voto (Estimulada)
              </h3>
            </div>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={voteData} layout="vertical" margin={{ left: 40 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                  <XAxis type="number" hide />
                  <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} />
                  <Tooltip cursor={{fill: '#f1f5f9'}} />
                  <Bar dataKey="votos" fill="#2563eb" radius={[0, 4, 4, 0]} barSize={20}>
                      {voteData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Rejection Pie Chart */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 break-inside-avoid">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-slate-700 flex items-center">
                <Icons.Chart className="w-5 h-5 mr-2 text-red-600" />
                Índice de Rejeição
              </h3>
            </div>
            <div className="h-64 w-full flex justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                      data={rejectionData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                  >
                      {rejectionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                  </Pie>
                  <Tooltip />
                  <Legend verticalAlign="bottom" height={36}/>
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* Geo Map Simulation */}
      {filteredResponses.length > 0 && (
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 break-inside-avoid">
          <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-slate-700 flex items-center">
                <Icons.Map className="w-5 h-5 mr-2 text-green-600" />
                Distribuição Geográfica das Coletas
              </h3>
              <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">GPS Validado</span>
            </div>
            <div className="h-64 w-full bg-slate-50 rounded-lg border border-slate-100 relative overflow-hidden">
              <ResponsiveContainer width="100%" height="100%">
                  <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" dataKey="x" name="Longitude" domain={['auto', 'auto']} hide />
                    <YAxis type="number" dataKey="y" name="Latitude" domain={['auto', 'auto']} hide />
                    <Tooltip cursor={{ strokeDasharray: '3 3' }} content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="bg-white p-2 border shadow-sm text-xs rounded">
                              <p>Local: {payload[0].payload.neighborhood}</p>
                            </div>
                          );
                        }
                        return null;
                    }} />
                    <Scatter name="Entrevistas" data={mapPoints} fill="#2563eb" />
                  </ScatterChart>
              </ResponsiveContainer>
              <p className="absolute bottom-2 right-2 text-[10px] text-slate-400">Mapa Esquemático (Lat/Lng)</p>
            </div>
        </div>
      )}

      {/* AI Analysis Section */}
      <div className="bg-gradient-to-br from-indigo-900 to-slate-900 rounded-xl shadow-xl text-white overflow-hidden break-inside-avoid">
         <div className="p-8 border-b border-indigo-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
                <h3 className="text-2xl font-bold flex items-center gap-2">
                    <Icons.AI className="w-8 h-8 text-yellow-400" />
                    Cientista Político Virtual
                </h3>
                <p className="text-indigo-200 text-sm mt-1">
                    Utilize IA para gerar diagnósticos, identificar tendências e sugerir estratégias de campanha.
                </p>
            </div>
            <button 
                onClick={handleGenerateReport}
                disabled={analyzing || filteredResponses.length === 0}
                className="no-print bg-yellow-400 hover:bg-yellow-500 text-slate-900 font-bold py-3 px-6 rounded-lg transition shadow-lg shadow-yellow-400/20 flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
                {analyzing ? <Icons.Spinner className="animate-spin mr-2" /> : <Icons.AI className="mr-2 w-5 h-5" />}
                {analyzing ? 'Analisando Dados...' : 'Gerar Relatório Estratégico'}
            </button>
         </div>
         
         {analysis && (
             <div className="p-8 bg-slate-800/50 print:bg-white print:text-black">
                <div className="prose prose-invert max-w-none print:prose-neutral">
                    <ReactMarkdown>{analysis}</ReactMarkdown>
                </div>
             </div>
         )}
      </div>
    </div>
  );
};