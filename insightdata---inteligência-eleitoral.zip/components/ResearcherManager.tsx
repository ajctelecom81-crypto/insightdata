import React, { useState, useEffect, useMemo } from 'react';
import { User, UserRole, SurveyResponse } from '../types';
import { getUsers, registerResearcher, deleteUser, getResponses } from '../services/storageService';
import { Icons } from './Icons';
import { 
  ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';

export const ResearcherManager: React.FC = () => {
  // Main State
  const [users, setUsers] = useState<User[]>([]);
  const [responses, setResponses] = useState<SurveyResponse[]>([]);
  
  // Registration State
  const [newName, setNewName] = useState('');
  const [lastCreatedToken, setLastCreatedToken] = useState<string | null>(null);
  
  // Modal/View State
  const [userToDelete, setUserToDelete] = useState<string | null>(null);
  const [selectedResearcher, setSelectedResearcher] = useState<User | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const allUsers = getUsers();
    setUsers(allUsers.filter(u => u.role === UserRole.RESEARCHER));
    setResponses(getResponses());
  };

  const handleRegister = () => {
    if (!newName) {
      alert("Preencha o nome do pesquisador.");
      return;
    }
    
    const newUser = registerResearcher(newName);
    setLastCreatedToken(newUser.token || null);
    setNewName('');
    loadData();
  };

  // --- Deletion Logic ---
  const promptDelete = (id: string) => {
    setUserToDelete(id);
  };

  const confirmDelete = () => {
    if (userToDelete) {
        deleteUser(userToDelete);
        loadData();
        setUserToDelete(null);
    }
  };

  const cancelDelete = () => {
      setUserToDelete(null);
  }

  // --- Researcher Stats Logic ---
  const researcherStats = useMemo(() => {
    if (!selectedResearcher) return null;

    const userResponses = responses.filter(r => r.researcherId === selectedResearcher.id);
    const sortedResponses = [...userResponses].sort((a, b) => 
        new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime()
    );

    const totalCollected = userResponses.length;
    const lastActivity = sortedResponses.length > 0 ? new Date(sortedResponses[0].submittedAt).toLocaleString() : 'N/A';
    
    // Map Data
    const mapPoints = userResponses.map(r => ({
      x: r.location.lng,
      y: r.location.lat,
      z: 1,
      neighborhood: r.respondentProfile.neighborhood,
      time: new Date(r.submittedAt).toLocaleTimeString()
    }));

    return {
        totalCollected,
        lastActivity,
        history: sortedResponses.slice(0, 10), // Last 10
        mapPoints
    };
  }, [selectedResearcher, responses]);


  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert("Token copiado!");
  };

  // --- VIEW: Detail Page ---
  if (selectedResearcher && researcherStats) {
      return (
        <div className="max-w-6xl mx-auto space-y-6">
            {/* Header with Back Button */}
            <div className="flex items-center gap-4">
                <button 
                    onClick={() => setSelectedResearcher(null)}
                    className="p-2 bg-white border border-slate-200 rounded-lg text-slate-500 hover:bg-slate-50 hover:text-blue-600 transition"
                >
                    <Icons.Logout className="w-5 h-5 rotate-180" /> {/* Rotating logout to look like back arrow */}
                </button>
                <div>
                    <h2 className="text-2xl font-bold text-slate-800">{selectedResearcher.name}</h2>
                    <p className="text-slate-500 text-sm">Token: <span className="font-mono">{selectedResearcher.token}</span></p>
                </div>
            </div>

            {/* KPI Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-blue-100 text-blue-600 rounded-full">
                            <Icons.Check className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-sm text-slate-500 font-medium">Total de Coletas</p>
                            <h3 className="text-2xl font-bold text-slate-800">{researcherStats.totalCollected}</h3>
                        </div>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-green-100 text-green-600 rounded-full">
                            <Icons.Calendar className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-sm text-slate-500 font-medium">Última Atividade</p>
                            <h3 className="text-lg font-bold text-slate-800">{researcherStats.lastActivity}</h3>
                        </div>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                     <div className="flex items-center gap-4">
                        <div className="p-3 bg-indigo-100 text-indigo-600 rounded-full">
                            <Icons.Map className="w-6 h-6" />
                        </div>
                        <div>
                            <p className="text-sm text-slate-500 font-medium">Áreas de Atuação</p>
                            <h3 className="text-lg font-bold text-slate-800">
                                {[...new Set(researcherStats.history.map(r => r.respondentProfile.neighborhood))].slice(0, 2).join(', ') || 'Nenhuma'}
                                {researcherStats.history.length > 0 && '...'}
                            </h3>
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Route Map */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
                    <h3 className="font-bold text-slate-700 mb-4 flex items-center">
                        <Icons.Map className="w-5 h-5 mr-2 text-slate-400" /> Rota de Coleta (GPS)
                    </h3>
                    <div className="h-80 w-full bg-slate-50 rounded-lg border border-slate-100 relative overflow-hidden">
                        {researcherStats.mapPoints.length > 0 ? (
                            <ResponsiveContainer width="100%" height="100%">
                                <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis type="number" dataKey="x" hide />
                                    <YAxis type="number" dataKey="y" hide />
                                    <Tooltip cursor={{ strokeDasharray: '3 3' }} content={({ active, payload }) => {
                                        if (active && payload && payload.length) {
                                            const data = payload[0].payload;
                                            return (
                                                <div className="bg-white p-2 border shadow-sm text-xs rounded z-50">
                                                    <p className="font-bold">{data.neighborhood}</p>
                                                    <p>Hora: {data.time}</p>
                                                </div>
                                            );
                                        }
                                        return null;
                                    }} />
                                    <Scatter name="Coletas" data={researcherStats.mapPoints} fill="#2563eb" />
                                </ScatterChart>
                            </ResponsiveContainer>
                        ) : (
                            <div className="flex items-center justify-center h-full text-slate-400">Sem dados de GPS</div>
                        )}
                        <p className="absolute bottom-2 right-2 text-[10px] text-slate-400">Lat/Lng Plot</p>
                    </div>
                </div>

                {/* History List */}
                <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                    <div className="px-6 py-4 border-b border-slate-100 bg-slate-50">
                        <h3 className="font-bold text-slate-700">Últimas 10 Coletas</h3>
                    </div>
                    <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
                        {researcherStats.history.length === 0 ? (
                            <div className="p-6 text-center text-slate-500 text-sm">Nenhuma coleta registrada.</div>
                        ) : (
                            researcherStats.history.map(r => (
                                <div key={r.id} className="p-4 hover:bg-slate-50 transition">
                                    <div className="flex justify-between items-start mb-1">
                                        <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                                            {r.respondentProfile.neighborhood}
                                        </span>
                                        <span className="text-xs text-slate-400">
                                            {new Date(r.submittedAt).toLocaleDateString()} {new Date(r.submittedAt).toLocaleTimeString()}
                                        </span>
                                    </div>
                                    <p className="text-sm text-slate-700">
                                        <span className="text-slate-500">Perfil:</span> {r.respondentProfile.gender}, {r.respondentProfile.ageGroup}
                                    </p>
                                    <p className="text-sm text-slate-700 truncate">
                                        <span className="text-slate-500">Voto:</span> {r.answers['q1']}
                                    </p>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>
        </div>
      );
  }

  // --- VIEW: Main List ---
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex justify-between items-end">
        <div>
           <h2 className="text-3xl font-bold text-slate-800">Equipe de Campo</h2>
           <p className="text-slate-500">Gerencie os pesquisadores e seus acessos.</p>
        </div>
      </div>

      {/* Register Form */}
      <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
        <h3 className="font-bold text-lg text-slate-700 flex items-center mb-4">
            <Icons.Plus className="w-5 h-5 mr-2" /> Cadastrar Novo Pesquisador
        </h3>
        <div className="flex flex-col md:flex-row gap-4 items-end">
            <div className="flex-1 w-full">
                <label className="block text-sm font-medium text-slate-700 mb-1">Nome Completo</label>
                <input 
                    value={newName}
                    onChange={e => setNewName(e.target.value)}
                    className="w-full p-2 border rounded-lg bg-slate-50 outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Ex: Ana Silva"
                />
            </div>
            <button 
                onClick={handleRegister}
                className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg transition shadow flex items-center h-[42px]"
            >
                <Icons.Key className="w-4 h-4 mr-2" /> Gerar Token
            </button>
        </div>

        {/* Success Message */}
        {lastCreatedToken && (
            <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center justify-between animate-in fade-in slide-in-from-top-4 duration-300">
                <div>
                    <p className="text-sm text-green-800 font-bold mb-1">Pesquisador cadastrado com sucesso!</p>
                    <p className="text-sm text-green-700">Envie este token de acesso: <span className="font-mono bg-white px-2 py-0.5 rounded border border-green-200 select-all">{lastCreatedToken}</span></p>
                </div>
                <button 
                    onClick={() => copyToClipboard(lastCreatedToken)}
                    className="text-green-700 hover:text-green-900 bg-green-100 p-2 rounded-lg"
                    title="Copiar Token"
                >
                    <Icons.Copy className="w-5 h-5" />
                </button>
            </div>
        )}
      </div>

      {/* Users List */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
         <div className="px-6 py-4 border-b border-slate-100 bg-slate-50">
             <h3 className="font-bold text-slate-700">Pesquisadores Ativos ({users.length})</h3>
         </div>
         <div className="divide-y divide-slate-100">
             {users.length === 0 ? (
                 <div className="p-8 text-center text-slate-500">Nenhum pesquisador cadastrado.</div>
             ) : (
                 users.map(u => (
                     <div key={u.id} className="p-4 flex flex-col md:flex-row md:items-center justify-between hover:bg-slate-50 transition gap-4">
                         <div className="flex items-center gap-4">
                             <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold">
                                 {u.name.charAt(0)}
                             </div>
                             <div>
                                 <p className="font-medium text-slate-800">{u.name}</p>
                                 <p className="text-xs text-slate-400">
                                   {u.email.includes('@votocerto.local') ? 'Login via Token' : u.email}
                                 </p>
                             </div>
                         </div>
                         <div className="flex items-center gap-4 self-end md:self-auto">
                             <div className="text-right hidden sm:block">
                                 <p className="text-[10px] uppercase text-slate-400 font-bold">Token</p>
                                 <p className="font-mono text-sm bg-slate-100 px-2 py-0.5 rounded text-slate-600">{u.token || '---'}</p>
                             </div>
                             
                             <div className="flex items-center border-l border-slate-200 pl-4 ml-2 gap-2">
                                <button 
                                    onClick={() => setSelectedResearcher(u)}
                                    className="text-blue-600 hover:bg-blue-50 p-2 rounded transition flex items-center text-sm font-medium"
                                    title="Ver Desempenho"
                                >
                                    <Icons.Chart className="w-5 h-5 md:mr-1" />
                                    <span className="hidden md:inline">Desempenho</span>
                                </button>
                                <button 
                                    onClick={() => promptDelete(u.id)}
                                    className="text-slate-300 hover:text-red-500 hover:bg-red-50 p-2 rounded transition"
                                    title="Remover acesso"
                                >
                                    <Icons.Trash className="w-5 h-5" />
                                </button>
                             </div>
                         </div>
                     </div>
                 ))
             )}
         </div>
      </div>

      {/* Delete Confirmation Modal */}
      {userToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4 animate-in fade-in duration-200">
              <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full p-6 animate-in zoom-in-95 duration-200">
                  <div className="flex flex-col items-center text-center mb-6">
                      <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
                          <Icons.Trash className="w-6 h-6 text-red-600" />
                      </div>
                      <h3 className="text-lg font-bold text-slate-800">Remover Pesquisador?</h3>
                      <p className="text-sm text-slate-500 mt-2">
                          Esta ação revogará o acesso imediatamente. O histórico de coletas será mantido.
                      </p>
                  </div>
                  <div className="flex gap-3">
                      <button 
                          onClick={cancelDelete}
                          className="flex-1 py-2.5 px-4 border border-slate-300 rounded-lg text-slate-700 font-medium hover:bg-slate-50 transition"
                      >
                          Cancelar
                      </button>
                      <button 
                          onClick={confirmDelete}
                          className="flex-1 py-2.5 px-4 bg-red-600 text-white rounded-lg font-bold hover:bg-red-700 shadow-md shadow-red-600/20 transition"
                      >
                          Sim, remover
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};