import React, { useState, useEffect } from 'react';
import { Survey, User, SurveyResponse, QuestionType } from '../types';
import { saveResponse } from '../services/storageService';
import { Icons } from './Icons';

interface Props {
  user: User;
  survey: Survey;
  onSubmitSuccess: () => void;
}

// Haversine formula to calculate distance between two points in meters
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371e3; // Radius of Earth in meters
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
            Math.cos(φ1) * Math.cos(φ2) *
            Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

export const DataCollection: React.FC<Props> = ({ user, survey, onSubmitSuccess }) => {
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [profile, setProfile] = useState({ ageGroup: '', gender: '', neighborhood: '' });
  const [loading, setLoading] = useState(false);
  const [gpsError, setGpsError] = useState('');
  const [currentStep, setCurrentStep] = useState(0); // 0 = Profile, 1 = Survey

  const handleAnswer = (qId: string, val: any) => {
    setAnswers(prev => ({ ...prev, [qId]: val }));
  };

  const submitForm = () => {
    setLoading(true);
    setGpsError('');

    if (!navigator.geolocation) {
      setGpsError('GPS não suportado neste dispositivo.');
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const currentLat = position.coords.latitude;
        const currentLng = position.coords.longitude;

        // --- Geofence Validation ---
        if (survey.targetLocation && survey.allowedRadius) {
           const distance = calculateDistance(
             currentLat, 
             currentLng, 
             survey.targetLocation.lat, 
             survey.targetLocation.lng
           );

           if (distance > survey.allowedRadius) {
             const distKm = (distance / 1000).toFixed(2);
             const limitKm = (survey.allowedRadius / 1000).toFixed(2);
             
             setGpsError(`BLOQUEIO DE SEGURANÇA: Você está fora da área permitida.\n\nDistância atual do centro: ${distKm}km\nLimite permitido: ${limitKm}km\n\nRetorne à área da pesquisa para enviar.`);
             setLoading(false);
             return;
           }
        }
        // ---------------------------

        const response: SurveyResponse = {
          id: Date.now().toString(),
          surveyId: survey.id,
          researcherId: user.id,
          researcherName: user.name,
          location: {
            lat: currentLat,
            lng: currentLng,
            accuracy: position.coords.accuracy,
            timestamp: position.timestamp
          },
          submittedAt: new Date().toISOString(),
          respondentProfile: profile as any,
          answers
        };

        saveResponse(response);
        
        setTimeout(() => {
          setLoading(false);
          alert("Coleta realizada com sucesso!");
          setAnswers({});
          setProfile({ ageGroup: '', gender: '', neighborhood: '' });
          setCurrentStep(0);
          onSubmitSuccess();
        }, 1000); // Simulate network delay
      },
      (error) => {
        setLoading(false);
        setGpsError(`Erro ao obter GPS: ${error.message}. Verifique a permissões.`);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  if (currentStep === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 max-w-lg mx-auto">
        <h2 className="text-xl font-bold text-slate-800 mb-4">Perfil do Eleitor</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Faixa Etária</label>
            <select 
              className="w-full p-3 border rounded-lg bg-slate-50"
              value={profile.ageGroup}
              onChange={(e) => setProfile({...profile, ageGroup: e.target.value})}
            >
              <option value="">Selecione...</option>
              <option value="16-24">16-24 anos</option>
              <option value="25-34">25-34 anos</option>
              <option value="35-44">35-44 anos</option>
              <option value="45-59">45-59 anos</option>
              <option value="60+">60+ anos</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Sexo</label>
            <select 
               className="w-full p-3 border rounded-lg bg-slate-50"
               value={profile.gender}
               onChange={(e) => setProfile({...profile, gender: e.target.value})}
            >
              <option value="">Selecione...</option>
              <option value="M">Masculino</option>
              <option value="F">Feminino</option>
              <option value="Outro">Outro</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Bairro</label>
            <select 
               className="w-full p-3 border rounded-lg bg-slate-50"
               value={profile.neighborhood}
               onChange={(e) => setProfile({...profile, neighborhood: e.target.value})}
            >
               <option value="">Selecione...</option>
               <option value="Centro">Centro</option>
               <option value="Zona Sul">Zona Sul</option>
               <option value="Zona Norte">Zona Norte</option>
               <option value="Zona Leste">Zona Leste</option>
               <option value="Zona Oeste">Zona Oeste</option>
            </select>
          </div>
          <button 
            disabled={!profile.ageGroup || !profile.gender || !profile.neighborhood}
            onClick={() => setCurrentStep(1)}
            className="w-full mt-4 bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 transition"
          >
            Iniciar Questionário
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 max-w-lg mx-auto relative">
      <div className="absolute top-4 right-4 text-xs text-slate-400 flex items-center">
        <Icons.Map className="w-3 h-3 mr-1" /> GPS Ativo
      </div>
      
      <h2 className="text-xl font-bold text-slate-800 mb-2">{survey.title}</h2>
      <p className="text-sm text-slate-500 mb-6 border-b pb-4">{survey.description}</p>
      
      {survey.targetLocation && (
        <div className="mb-6 p-3 bg-blue-50 border border-blue-100 rounded-lg text-xs text-blue-700 flex items-center">
            <Icons.Map className="w-4 h-4 mr-2 flex-shrink-0" />
            <span>Coleta restrita a um raio de {survey.allowedRadius ? survey.allowedRadius / 1000 : 0}km da área alvo.</span>
        </div>
      )}

      <div className="space-y-6">
        {survey.questions.map((q) => (
          <div key={q.id}>
            <label className="block text-base font-medium text-slate-800 mb-2">{q.text}</label>
            
            {q.type === QuestionType.SINGLE_CHOICE && (
              <div className="space-y-2">
                {q.options?.map(opt => (
                  <label key={opt} className="flex items-center space-x-3 p-3 border rounded-lg bg-slate-50 hover:bg-slate-100 cursor-pointer">
                    <input 
                      type="radio" 
                      name={q.id} 
                      value={opt}
                      checked={answers[q.id] === opt}
                      onChange={() => handleAnswer(q.id, opt)}
                      className="w-4 h-4 text-blue-600"
                    />
                    <span className="text-slate-700">{opt}</span>
                  </label>
                ))}
              </div>
            )}

            {q.type === QuestionType.SCALE && (
              <div className="flex justify-between gap-2">
                {[1, 2, 3, 4, 5].map(num => (
                  <button
                    key={num}
                    onClick={() => handleAnswer(q.id, num)}
                    className={`flex-1 py-3 rounded-lg font-bold transition ${answers[q.id] === num ? 'bg-blue-600 text-white shadow-md' : 'bg-slate-100 text-slate-600'}`}
                  >
                    {num}
                  </button>
                ))}
                <div className="flex justify-between w-full absolute -bottom-5 text-[10px] text-slate-400 px-1 opacity-0">
                    <span>Ruim</span><span>Ótimo</span>
                </div>
              </div>
            )}

             {q.type === QuestionType.BOOLEAN && (
              <div className="flex gap-3">
                 <button 
                   onClick={() => handleAnswer(q.id, true)}
                   className={`flex-1 py-3 border rounded-lg ${answers[q.id] === true ? 'bg-green-100 border-green-500 text-green-700' : 'bg-slate-50'}`}
                 >Sim</button>
                 <button 
                   onClick={() => handleAnswer(q.id, false)}
                   className={`flex-1 py-3 border rounded-lg ${answers[q.id] === false ? 'bg-red-100 border-red-500 text-red-700' : 'bg-slate-50'}`}
                 >Não</button>
              </div>
            )}
            
            {q.type === QuestionType.TEXT && (
                <textarea 
                  className="w-full border p-3 rounded-lg bg-slate-50"
                  rows={3}
                  value={answers[q.id] || ''}
                  onChange={(e) => handleAnswer(q.id, e.target.value)}
                />
            )}
          </div>
        ))}
      </div>

      {gpsError && (
        <div className="mt-8 p-4 bg-red-100 border border-red-200 text-red-800 rounded-lg text-sm flex items-start animate-in fade-in slide-in-from-bottom-2">
          <Icons.Map className="w-5 h-5 mr-2 mt-0.5 flex-shrink-0" />
          <div className="whitespace-pre-line font-medium">{gpsError}</div>
        </div>
      )}

      <button
        onClick={submitForm}
        disabled={loading || Object.keys(answers).length < survey.questions.length}
        className="w-full mt-8 bg-green-600 hover:bg-green-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-green-600/20 disabled:opacity-50 disabled:shadow-none flex items-center justify-center transition"
      >
        {loading ? <Icons.Spinner className="animate-spin mr-2" /> : <Icons.Send className="mr-2 w-5 h-5" />}
        {loading ? 'Validando Localização...' : 'Finalizar e Enviar Coleta'}
      </button>
      
      <button onClick={() => setCurrentStep(0)} className="w-full mt-3 text-slate-400 text-sm">Cancelar</button>
    </div>
  );
};