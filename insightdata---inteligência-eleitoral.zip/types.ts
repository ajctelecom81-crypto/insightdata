export enum UserRole {
  ADMIN = 'ADMIN',
  RESEARCHER = 'RESEARCHER'
}

export interface User {
  id: string;
  name: string;
  role: UserRole;
  email: string;
  token?: string; // Token de acesso gerado
}

export enum QuestionType {
  SINGLE_CHOICE = 'SINGLE_CHOICE',
  SCALE = 'SCALE', // 1-5
  TEXT = 'TEXT',
  BOOLEAN = 'BOOLEAN' // Sim/Não
}

export interface Question {
  id: string;
  text: string;
  type: QuestionType;
  options?: string[]; // For single choice
}

export interface Survey {
  id: string;
  title: string;
  description: string;
  questions: Question[];
  active: boolean;
  region: string;
  // Geofencing Config
  targetLocation?: {
    lat: number;
    lng: number;
  };
  allowedRadius?: number; // em metros
}

export interface GeoLocation {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: number;
}

export interface SurveyResponse {
  id: string;
  surveyId: string;
  researcherId: string;
  researcherName: string;
  location: GeoLocation;
  answers: Record<string, string | number | boolean>; // questionId -> answer
  submittedAt: string;
  respondentProfile: {
    ageGroup: string;
    gender: 'M' | 'F' | 'Outro';
    neighborhood: string;
  }
}

export interface AnalysisReport {
  id: string;
  generatedAt: string;
  markdownContent: string;
}